library(tidyverse)
library(readr)

#Creamos una tabla de medidas resumen de las facturaciones
coop_electr_factur_csv_num <- coop_electr_factur_csv %>%
  select_if(is.numeric)

#Medidas resumen
medidas_resumen_coop_electr_factur_csv_num <- summary(coop_electr_factur_csv_num)

#Definimos la función del desvío estándar poblacional
desvio_estandar_p <- function(x) {
 sd(x)*((length(x)-1)/length(x))^0.5
}

desvio_estandar_p_coop_electr_factur_csv_num <- sapply(coop_electr_factur_csv_num, desvio_estandar_p)

#Definimos la función del coeficiente de variación
coeficiente_variacion <- function(x) {
  desvio_estandar_p(x)/mean(x)
  }

coeficiente_variacion_coop_electr_factur_csv_num <- sapply(coop_electr_factur_csv_num, coeficiente_variacion)



#Creamos una tabla de medidas resumen de los usuarios
coop_electr_usu_csv_num <- coop_electr_usu_csv %>%
  select_if(is.numeric)

#Medidas resumen
medidas_resumen_coop_electr_usu_csv_num <- summary(coop_electr_usu_csv_num)

#Definimos la función del desvío estándar poblacional
desvio_estandar_p <- function(x) {
  sd(x, na.rm = TRUE)*((length(x)-1)/length(x))^0.5
}

desvio_estandar_p_coop_electr_usu_csv_num <- sapply(coop_electr_usu_csv_num, desvio_estandar_p)

#Definimos la función del coeficiente de variación
coeficiente_variacion <- function(x) {
  desvio_estandar_p(x)/mean(x, na.rm = TRUE)
}

coeficiente_variacion_coop_electr_usu_csv_num <- sapply(coop_electr_usu_csv_num, coeficiente_variacion)


#Grabamos las medidas resumen de las facturaciones
write.csv(medidas_resumen_coop_electr_factur_csv_num, "medidas_resumen_coop_electr_factur_csv_num.csv")
write.csv(desvio_estandar_p_coop_electr_factur_csv_num, "desvio_estandar_p_coop_electr_factur_csv_num.csv")
write.csv(coeficiente_variacion_coop_electr_factur_csv_num, "coeficiente_variacion_coop_electr_factur_csv_num.csv")


#Grabamos las medidas resumen de los usuarios
write.csv(medidas_resumen_coop_electr_usu_csv_num, "medidas_resumen_coop_electr_usu_csv_num.csv")
write.csv(desvio_estandar_p_coop_electr_usu_csv_num, "desvio_estandar_p_coop_electr_usu_csv_num.csv")
write.csv(coeficiente_variacion_coop_electr_usu_csv_num, "coeficiente_variacion_coop_electr_usu_csv_num.csv")