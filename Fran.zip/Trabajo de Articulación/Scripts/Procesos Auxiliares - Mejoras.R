#Limpiamos la tabla de usuarios
coop_electr_usu <- coop_electr_usu[!grepl("Total", coop_electr_usu$...1), ]
coop_electr_usu <- coop_electr_usu[!grepl("COOPERATIVAS", coop_electr_usu$...1), ]
coop_electr_usu <- coop_electr_usu[!grepl("cooperativas", coop_electr_usu$...1), ]
coop_electr_usu <- coop_electr_usu[!grepl("TOTAL", coop_electr_usu$...1), ]
coop_electr_usu <- coop_electr_usu[!grepl("Coop", coop_electr_usu$...1), ]
coop_electr_usu <- coop_electr_usu %>%
  dplyr::filter(coop_electr_usu$...3 != 0)
coop_electr_usu <- coop_electr_usu[order(coop_electr_usu$...1, coop_electr_usu$...2),]


coop_electr_usu %>%
  dplyr::filter(
    coop_electr_usu$...1 != "Total",
    coop_electr_usu$...1 != "COOPERATIVAS",    
    coop_electr_usu$...1 != "cooperativas",    
    coop_electr_usu$...1 != "TOTAL",   
    coop_electr_usu$...1 != "Coop",    
    coop_electr_usu$...3 != 0
    )
coop_electr_usu <- coop_electr_usu[complete.cases(coop_electr_usu),]