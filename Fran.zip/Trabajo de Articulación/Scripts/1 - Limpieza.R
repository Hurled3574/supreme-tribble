install.packages("tidyverse")
install.packages("Rcpp")
library(tidyverse)
library(readxl)
-----------------------------
#Listamos todas las planillas del Informe para, eventualmente, iterar. No sé iterar.
Lista_Informe_Cooperativas_2014 <- list.files("Datos/informecooperativas2014", pattern = "\\.xls$", full.names = TRUE)

#Cargamos las bases de datos de facturación
coopareaEDEA14_factur <- read_excel("Datos/informecooperativas2014/coopareaEDEA14.xls", sheet = "edeafactur",skip = 7, col_names = FALSE)
CoopareaEDEN14_factur <- read_excel("Datos/informecooperativas2014/CoopareaEDEN14.xls", sheet = "edenfactur",skip = 6, n_max = 193, col_names = FALSE)
coopareaEDENOR14_factur <- read_excel("Datos/informecooperativas2014/coopareaEDENOR14.xls", sheet = "edenorfactur", skip = 6, col_names = FALSE)
CoopareaEDES14_factur <- read_excel("Datos/informecooperativas2014/CoopareaEDES14.xls", sheet = "edesfactur", skip = 6, col_names = FALSE)
Coopchaco14_factur <- read_excel("Datos/informecooperativas2014/Coopchaco14.xls", sheet = "chacofactur", skip = 6, col_names = FALSE)
CoopChubut14_factur <- read_excel("Datos/informecooperativas2014/CoopChubut14.xls", sheet = "chubutfactur", skip = 6, col_names = FALSE)
Coopcordoba14_factur <- read_excel("Datos/informecooperativas2014/Coopcordoba14.xls", sheet = "cordobafactur", skip = 6, col_names = FALSE)
Coopcorrientes14_factur <- read_excel("Datos/informecooperativas2014/Coopcorrientes14.xls", sheet = "corrientesfactur", skip = 6, col_names = FALSE)
Coopentrerios14_factur <- read_excel("Datos/informecooperativas2014/Coopentrerios14.xls", sheet = "entreriosfactur", skip = 6, col_names = FALSE)
coopformosa14_factur <- read_excel("Datos/informecooperativas2014/coopformosa14.xls", sheet = "formosafactur", skip = 6, col_names = FALSE)
Cooplapampa14_factur <- read_excel("Datos/informecooperativas2014/Cooplapampa14.xls", sheet = "lapampafactur", skip = 6, col_names = FALSE)
Coopmendoza14_factur <- read_excel("Datos/informecooperativas2014/Coopmendoza14.xls", sheet = "mendozafactur", skip = 6, col_names = FALSE)
Coopmisiones14_factur <- read_excel("Datos/informecooperativas2014/Coopmisiones14.xls", sheet = "misionesfactur", skip = 6, col_names = FALSE)
Coopneuquen14_factur <- read_excel("Datos/informecooperativas2014/Coopneuquen14.xls", sheet = "neuquenfactur", skip = 6, col_names = FALSE)
Cooprionegro14_factur <- read_excel("Datos/informecooperativas2014/Cooprionegro14.xls", sheet = "rionegrofactur", skip = 6, col_names = FALSE)
Coopsanjuan14_factur <- read_excel("Datos/informecooperativas2014/Coopsanjuan14.xls", sheet = "sanjuanfactur", skip = 6, col_names = FALSE)
Coopsantacruz14_factur <- read_excel("Datos/informecooperativas2014/Coopsantacruz14.xls", sheet = "santacruzfactur", skip = 6, col_names = FALSE)
Coopsantafe14_factur <- read_excel("Datos/informecooperativas2014/Coopsantafe14.xls", sheet = "santafefactur", skip = 6, col_names = FALSE)
Coopsgodelestero14_factur <- read_excel("Datos/informecooperativas2014/Coopsgodelestero14.xls", sheet = "sgodelesterofactur", skip = 6, col_names = FALSE)
Cooptierradelfuego14_factur <- read_excel("Datos/informecooperativas2014/Cooptierradelfuego14.xls", sheet = "tdelfuegofactur", skip = 6, col_names = FALSE)

#Cargamos las bases de datos de usuario
coopareaEDEA14_usu <- read_excel("Datos/informecooperativas2014/coopareaEDEA14.xls", sheet = "edeausu",skip = 7, col_names = FALSE)
CoopareaEDEN14_usu <- read_excel("Datos/informecooperativas2014/CoopareaEDEN14.xls", sheet = "edenusu",skip = 5, n_max = 193, col_names = FALSE)
coopareaEDENOR14_usu <- read_excel("Datos/informecooperativas2014/coopareaEDENOR14.xls", sheet = "edenorusu", skip = 5, col_names = FALSE)
CoopareaEDES14_usu <- read_excel("Datos/informecooperativas2014/CoopareaEDES14.xls", sheet = "edesusu", skip = 6, col_names = FALSE)
Coopchaco14_usu <- read_excel("Datos/informecooperativas2014/Coopchaco14.xls", sheet = "chacousu", skip = 6, col_names = FALSE)
CoopChubut14_usu <- read_excel("Datos/informecooperativas2014/CoopChubut14.xls", sheet = "chubutusu", skip = 6, col_names = FALSE)
Coopcordoba14_usu <- read_excel("Datos/informecooperativas2014/Coopcordoba14.xls", sheet = "cordobausu", skip = 6, col_names = FALSE)
Coopcorrientes14_usu <- read_excel("Datos/informecooperativas2014/Coopcorrientes14.xls", sheet = "corrientesusu", skip = 6, col_names = FALSE)
Coopentrerios14_usu <- read_excel("Datos/informecooperativas2014/Coopentrerios14.xls", sheet = "entreriosusu", skip = 6, col_names = FALSE)
coopformosa14_usu <- read_excel("Datos/informecooperativas2014/coopformosa14.xls", sheet = "formosausu", skip = 6, col_names = FALSE)
Cooplapampa14_usu <- read_excel("Datos/informecooperativas2014/Cooplapampa14.xls", sheet = "lapampausu", skip = 6, col_names = FALSE)
Coopmendoza14_usu <- read_excel("Datos/informecooperativas2014/Coopmendoza14.xls", sheet = "mendozausu", skip = 6, col_names = FALSE)
Coopmisiones14_usu <- read_excel("Datos/informecooperativas2014/Coopmisiones14.xls", sheet = "misionesusu", skip = 6, col_names = FALSE)
Coopneuquen14_usu <- read_excel("Datos/informecooperativas2014/Coopneuquen14.xls", sheet = "neuquenusu", skip = 6, col_names = FALSE)
Cooprionegro14_usu <- read_excel("Datos/informecooperativas2014/Cooprionegro14.xls", sheet = "rionegrousu", skip = 6, col_names = FALSE)
Coopsanjuan14_usu <- read_excel("Datos/informecooperativas2014/Coopsanjuan14.xls", sheet = "sanjuanusu", skip = 6, col_names = FALSE)
Coopsantacruz14_usu <- read_excel("Datos/informecooperativas2014/Coopsantacruz14.xls", sheet = "santacruzusu", skip = 6, col_names = FALSE)
Coopsantafe14_usu <- read_excel("Datos/informecooperativas2014/Coopsantafe14.xls", sheet = "santafeusu", skip = 6, col_names = FALSE)
Coopsgodelestero14_usu <- read_excel("Datos/informecooperativas2014/Coopsgodelestero14.xls", sheet = "sgodelesterousu", skip = 6, col_names = FALSE)
Cooptierradelfuego14_usu <- read_excel("Datos/informecooperativas2014/Cooptierradelfuego14.xls", sheet = "tdelfuegousu", skip = 6, col_names = FALSE)

#Eliminamos una columna de más para combinar tablas
coopareaEDEA14_factur <- subset(coopareaEDEA14_factur, select = -...14)

#Combinamos tablas de facturación
coop_electr_factur <- dplyr::bind_rows(
  coopareaEDEA14_factur,
  coopareaEDENOR14_factur,
  CoopareaEDEN14_factur,
  CoopareaEDES14_factur,
  Coopchaco14_factur,
  CoopChubut14_factur,
  Coopcordoba14_factur,
  Coopcorrientes14_factur,
  Coopentrerios14_factur,
  coopformosa14_factur,
  Cooplapampa14_factur,
  Coopmendoza14_factur,
  Coopmisiones14_factur,
  Coopneuquen14_factur,
  Cooprionegro14_factur,
  Coopsanjuan14_factur,
  Coopsantacruz14_factur,
  Coopsantafe14_factur,
  Coopsgodelestero14_factur,
  Cooptierradelfuego14_factur
)

#Limpiamos la planilla de facturación
coop_electr_factur %>%
  dplyr::filter(
    coop_electr_factur$...1 != "Total",
    coop_electr_factur$...1 != "COOPERATIVAS",
    coop_electr_factur$...1 != "cooperativas",
    coop_electr_factur$...1 != "TOTAL",
    coop_electr_factur$...1 != "valores",
    coop_electr_factur$...1 != "cargado",
    coop_electr_factur$...1 != "manteniendo",
    coop_electr_factur$...1 != "Coop",
    coop_electr_factur$...1 != "estimado",
    coop_electr_factur$...1 != "compra",
    coop_electr_factur$...1 != "apropiado",
    coop_electr_factur$...3 != 0
  )
coop_electr_factur[complete.cases(coop_electr_factur),]

#Ordenamos el listado de facturaciones
coop_electr_factur <- coop_electr_factur[
  order(
    coop_electr_factur$...1, coop_electr_factur$...2
  ),
]

#Grabamos la limpieza hecha, y continuamos la limpieza en Openrefine
write.csv(coop_electr_factur, "coop_electr_factur.csv")

#Cargamos las bases de datos de usuario
coopareaEDEA14_usu <- read_excel("Datos/informecooperativas2014/coopareaEDEA14.xls", sheet = "edeausu",skip = 6, col_names = FALSE)
CoopareaEDEN14_usu <- read_excel("Datos/informecooperativas2014/CoopareaEDEN14.xls", sheet = "edenusu",skip = 6, n_max = 193, col_names = FALSE)
coopareaEDENOR14_usu <- read_excel("Datos/informecooperativas2014/coopareaEDENOR14.xls", sheet = "edenorusu", skip = 6, col_names = FALSE)
CoopareaEDES14_usu <- read_excel("Datos/informecooperativas2014/CoopareaEDES14.xls", sheet = "edesusu", skip = 6, col_names = FALSE)
Coopchaco14_usu <- read_excel("Datos/informecooperativas2014/Coopchaco14.xls", sheet = "chacousu", skip = 6, col_names = FALSE)
CoopChubut14_usu <- read_excel("Datos/informecooperativas2014/CoopChubut14.xls", sheet = "chubutusu", skip = 6, col_names = FALSE)
Coopcordoba14_usu <- read_excel("Datos/informecooperativas2014/Coopcordoba14.xls", sheet = "cordobausu", skip = 6, col_names = FALSE)
Coopcorrientes14_usu <- read_excel("Datos/informecooperativas2014/Coopcorrientes14.xls", sheet = "corrientesusu", skip = 6, col_names = FALSE)
Coopentrerios14_usu <- read_excel("Datos/informecooperativas2014/Coopentrerios14.xls", sheet = "entreriosusu", skip = 6, col_names = FALSE)
coopformosa14_usu <- read_excel("Datos/informecooperativas2014/coopformosa14.xls", sheet = "formosausu", skip = 6, col_names = FALSE)
Cooplapampa14_usu <- read_excel("Datos/informecooperativas2014/Cooplapampa14.xls", sheet = "lapampausu", skip = 6, col_names = FALSE)
Coopmendoza14_usu <- read_excel("Datos/informecooperativas2014/Coopmendoza14.xls", sheet = "mendozausu", skip = 6, col_names = FALSE)
Coopmisiones14_usu <- read_excel("Datos/informecooperativas2014/Coopmisiones14.xls", sheet = "misionesusu", skip = 6, col_names = FALSE)
Coopneuquen14_usu <- read_excel("Datos/informecooperativas2014/Coopneuquen14.xls", sheet = "neuquenusu", skip = 6, col_names = FALSE)
Cooprionegro14_usu <- read_excel("Datos/informecooperativas2014/Cooprionegro14.xls", sheet = "rionegrousu", skip = 6, col_names = FALSE)
Coopsanjuan14_usu <- read_excel("Datos/informecooperativas2014/Coopsanjuan14.xls", sheet = "sanjuanusu", skip = 6, col_names = FALSE)
Coopsantacruz14_usu <- read_excel("Datos/informecooperativas2014/Coopsantacruz14.xls", sheet = "santacruzusu", skip = 6, col_names = FALSE)
Coopsantafe14_usu <- read_excel("Datos/informecooperativas2014/Coopsantafe14.xls", sheet = "santafeusu", skip = 6, col_names = FALSE)
Coopsgodelestero14_usu <- read_excel("Datos/informecooperativas2014/Coopsgodelestero14.xls", sheet = "sgodelesterousu", skip = 6, col_names = FALSE)
Cooptierradelfuego14_usu <- read_excel("Datos/informecooperativas2014/Cooptierradelfuego14.xls", sheet = "tdelfuegousu", skip = 6, col_names = FALSE)

#Combinamos tablas de usuarios
coop_electr_usu <- dplyr::bind_rows(
  coopareaEDEA14_usu,
  coopareaEDENOR14_usu,
  CoopareaEDEN14_usu,
  CoopareaEDES14_usu,
  Coopchaco14_usu,
  CoopChubut14_usu,
  Coopcordoba14_usu,
  Coopcorrientes14_usu,
  Coopentrerios14_usu,
  coopformosa14_usu,
  Cooplapampa14_usu,
  Coopmendoza14_usu,
  Coopmisiones14_usu,
  Coopneuquen14_usu,
  Cooprionegro14_usu,
  Coopsanjuan14_usu,
  Coopsantacruz14_usu,
  Coopsantafe14_usu,
  Coopsgodelestero14_usu,
  Cooptierradelfuego14_usu
)

#Limpiamos la tabla de usuarios
coop_electr_usu <- coop_electr_usu %>%
  dplyr::filter(
    coop_electr_usu$...1 != "Total",
    coop_electr_usu$...1 != "COOPERATIVAS",    
    coop_electr_usu$...1 != "cooperativas",    
    coop_electr_usu$...1 != "TOTAL",   
    coop_electr_usu$...1 != "Coop",    
    coop_electr_usu$...3 != 0
  )
coop_electr_usu <- coop_electr_usu[
  complete.cases(coop_electr_usu),
]

#Grabamos la limpieza, y la continuamos en OpenRefine
write.csv(coop_electr_usu, "coop_electr_usu.csv")

--------

#Cargamos las bases de datos que limpiamos de manera fina con OpenRefine. En Open Refine, corregimos algunas tildes que faltaban en algunas palabras
coop_electr_factur_csv <- read_csv("coop-electr-factur-csv(1).csv")
coop_electr_usu_csv <- read_csv("coop-electr-usu-csv(1).csv")

#Se creó una columna de números innecesarios en ambas bases, quizás, desde el Openrefine. La borramos
coop_electr_factur_csv <- subset(coop_electr_factur_csv, select = -Column)
coop_electr_usu_csv <- subset(coop_electr_usu_csv, select = -Column)

#Necesitamos crear una primera fila con los títulos de las variables en ambas bases
colnames(coop_electr_factur_csv) <- c("Departamento","Ente","Total","Residencial","Comercial","Industrial","Serv Sanita","Al Público","Tracción","Riego","Oficial","E. Rural","Otros")
colnames(coop_electr_usu_csv) <- c("Departamento","Ente","Total","Residencial","Comercial","Industrial","Serv Sanita","Al Público","Tracción","Riego","Oficial","E. Rural","Otros")

#Necesitamos ordenar los datos de la base. ¿Cómo lo hacemos?
coop_electr_factur_csv <- coop_electr_factur_csv[order(coop_electr_factur_csv$Departamento, coop_electr_factur_csv$Ente),]
coop_electr_usu_csv <- coop_electr_usu_csv[order(coop_electr_usu_csv$Departamento, coop_electr_usu_csv$Ente),]

#Buscamos valores perdidos
table(coop_electr_factur_csv$Departamento, useNA = "always")
table(coop_electr_factur_csv$Ente, useNA = "always")
table(coop_electr_factur_csv$Total, useNA = "always")
table(coop_electr_factur_csv$Residencial, useNA = "always")
table(coop_electr_factur_csv$Comercial, useNA = "always")
table(coop_electr_factur_csv$Industrial, useNA = "always")
table(coop_electr_factur_csv$`Serv Sanita`, useNA = "always")
table(coop_electr_factur_csv$`Al Público`, useNA = "always")
table(coop_electr_factur_csv$Tracción, useNA = "always")
table(coop_electr_factur_csv$Riego, useNA = "always")
table(coop_electr_factur_csv$Oficial, useNA = "always")
table(coop_electr_factur_csv$`E. Rural`, useNA = "always")
table(coop_electr_factur_csv$Otros, useNA = "always")

table(coop_electr_usu_csv$Departamento, useNA = "always") #37 NAs
table(coop_electr_usu_csv$Ente, useNA = "always") #39 NAs
table(coop_electr_usu_csv$Total, useNA = "always") #39 NAs
table(coop_electr_usu_csv$Residencial, useNA = "always") #45 NAs
table(coop_electr_usu_csv$Comercial, useNA = "always") #45 NAs
table(coop_electr_usu_csv$Industrial, useNA = "always") #45 NAs
table(coop_electr_usu_csv$`Serv Sanita`, useNA = "always") #45 NAs
table(coop_electr_usu_csv$`Al Público`, useNA = "always") #45 NAs
table(coop_electr_usu_csv$Tracción, useNA = "always") #45 NAs
table(coop_electr_usu_csv$Riego, useNA = "always") #45 NAs
table(coop_electr_usu_csv$Oficial, useNA = "always") #45 NAs
table(coop_electr_usu_csv$`E. Rural`, useNA = "always") #45 NAs
table(coop_electr_usu_csv$Otros, useNA = "always") #45 NAs

write.csv(coop_electr_factur_csv, "coop_electr_factur_csv(2).csv")
write.csv(coop_electr_usu_csv, "coop_electr_usu_csv(2).csv")
